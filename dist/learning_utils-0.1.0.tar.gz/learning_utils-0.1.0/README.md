Python package to reduce iteration time for developing learning systems.

Use this command to install:

```
pip install learning_utils
```

